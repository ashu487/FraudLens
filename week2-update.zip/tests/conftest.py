import pathlib
import sys

sys.path.insert(0, str(pathlib.Path(__file__).parents[1] / "services" / "scoring"))
